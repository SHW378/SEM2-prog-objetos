public interface Administrable {
    void modificar(String tipoDato, String valor);
    void desactivar();
}
