class Vertice {
    String valor;
    Vertice izquierdo, derecho;

    public Vertice(String valor) {
        this.valor = valor;
        izquierdo = derecho = null;
    }
}